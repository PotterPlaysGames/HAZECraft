 1.10.2 & 1.11.2 are END OF LIFE, we will NOT be accepting PR's etc for those versions.

# Avaritia
Are you the type of modded Minecraft player that makes a beeline for the designated "end game" and then gives up on ever playing again once you get there? Do you wish there was a way to make the process take significantly longer? Do you love GregTech, but wish it weren't so short? Do you sit down on your chest full of Galgadorian Drills and wish there was a mod that didn't just hand things to you on a silver platter?

This might be the mod for you!


