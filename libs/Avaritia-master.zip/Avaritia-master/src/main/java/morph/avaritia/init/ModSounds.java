package morph.avaritia.init;

import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;

public class ModSounds {

    public static final SoundEvent GAPING_VOID = new SoundEvent(new ResourceLocation("avaritia:gaping_void"));

}
