package morph.avaritia.client.render.shader;

public abstract class ShaderCallback {

    public abstract void call(int shader);
}
